#!/system/bin/sh
echo "[RX FAST CHARGE] post-fs-data 已执行"
